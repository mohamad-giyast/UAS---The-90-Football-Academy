<?php
session_start();
include 'config.php';

$is_logged_in = isset($_SESSION['user_id']);
$user_name = $_SESSION['user_name'] ?? '';
$user_role = $_SESSION['role'] ?? 'guest';

// Ambil kata kunci dan urutan (sort)
$keyword = isset($_GET['q']) ? trim($_GET['q']) : '';
$sort = $_GET['sort'] ?? 'name_asc';

// Tentukan urutan query
switch ($sort) {
    case 'price_asc':
        $order_by = "price ASC";
        break;
    case 'price_desc':
        $order_by = "price DESC";
        break;
    default:
        $order_by = "name ASC";
        break;
}

// Query ambil data SSB
if ($keyword !== '') {
    $stmt = $conn->prepare("SELECT id, name, location, price FROM ssb WHERE name LIKE ? OR location LIKE ? ORDER BY $order_by");
    $search = "%$keyword%";
    $stmt->bind_param("ss", $search, $search);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT id, name, location, price FROM ssb ORDER BY $order_by");
}
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Cari SSB - The 90'</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
  <link rel="icon" type="image/png" href="Assets/logo-trans.png">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    html, body {
      min-height: 100%;
      overflow-y: auto;
      font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, 'Helvetica Neue', Arial;
    }
    .app-bg {
      background: linear-gradient(180deg, #071022 0%, #0b1220 60%, #071022 100%);
    }
    .card-glass {
      background: linear-gradient(180deg, rgba(255,255,255,0.05), rgba(255,255,255,0.02));
      backdrop-filter: blur(8px);
    }
    .accent {
      background: linear-gradient(90deg, #06b6d4, #7c3aed);
    }
    .loader {
      border: 3px solid rgba(255,255,255,0.2);
      border-top: 3px solid #06b6d4;
      border-radius: 50%;
      width: 36px;
      height: 36px;
      animation: spin 0.9s linear infinite;
    }
    @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    #dashboard-loading { transition: opacity 0.6s ease; }
  </style>
</head>

<body class="app-bg text-slate-100 antialiased min-h-screen flex flex-col relative">

  <!-- Splash Loading -->
  <div id="dashboard-loading" class="fixed inset-0 bg-slate-950 flex flex-col items-center justify-center z-50">
    <img src="Assets/logo-trans.png" alt="Logo" class="w-20 h-auto animate-bounce mb-4">
    <div class="loader"></div>
    <p class="mt-3 text-slate-300 text-sm tracking-wide">Memuat Daftar SSB...</p>
  </div>

  <!-- Navbar -->
  <nav class="px-4 py-4 flex items-center justify-between max-w-6xl mx-auto w-full relative">
    <div class="flex items-center gap-3">
      <div class="w-10 h-10 rounded-2xl overflow-hidden shadow-lg flex-shrink-0">
        <img src="Assets/logo.png" alt="Logo" class="w-full h-full object-cover">
      </div>
      <div>
        <span class="text-lg font-semibold block">The 90' : Football Academy</span>
        <div class="text-xs text-slate-400">Pendaftaran Sekolah Sepak Bola</div>
      </div>
    </div>

    <!-- Tombol hamburger -->
    <button id="menu-toggle" class="md:hidden p-2 rounded-lg card-glass focus:outline-none focus:ring-2 focus:ring-cyan-500">
      <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" 
           viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" 
              stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
      </svg>
    </button>

    <!-- Menu utama responsif -->
    <div 
      id="menu" 
      class="hidden md:flex flex-col md:flex-row absolute md:static top-full right-0 left-0 
             bg-slate-900 md:bg-transparent p-4 md:p-0 mt-2 md:mt-0 rounded-xl md:rounded-none 
             shadow-lg md:shadow-none z-50 transition-all duration-300 ease-in-out"
    >
      <a href="index.php" class="px-3 py-2 rounded-lg card-glass text-sm text-center mb-2 md:mb-0 md:mx-1 hover:bg-slate-800">Beranda</a>
      <a href="ssb-list.php" class="px-3 py-2 rounded-lg card-glass text-sm text-center mb-2 md:mb-0 md:mx-1 bg-slate-800">Cari SSB</a>
      <a href="daftar-ssb.php" class="px-3 py-2 rounded-lg card-glass text-sm text-center mb-2 md:mb-0 md:mx-1 hover:bg-slate-800">Daftar SSB</a>

      <?php if ($is_logged_in): ?>
        <a href="profile.php" class="px-3 py-2 rounded-lg card-glass text-sm text-center mb-2 md:mb-0 md:mx-1 hover:bg-slate-800">Profil</a>
        <?php if ($user_role === 'admin'): ?>
          <a href="admin/admin-dashboard.php" class="px-3 py-2 rounded-lg bg-purple-800 text-sm text-center mb-2 md:mb-0 md:mx-1 hover:bg-purple-700">Admin Panel</a>
        <?php endif; ?>
        <a href="logout.php" class="px-3 py-2 rounded-lg accent text-sm text-center shadow md:mx-1 hover:opacity-90">Keluar</a>
      <?php else: ?>
        <a href="login.php" class="px-3 py-2 rounded-lg accent text-sm text-center text-white font-semibold shadow md:mx-1 hover:opacity-90">Masuk</a>
      <?php endif; ?>
    </div>
  </nav>

  <!-- Konten utama -->
  <main class="flex-1 w-full max-w-5xl mx-auto px-4 pb-10 mt-6">
    <div class="card-glass rounded-2xl p-6 sm:p-8 mt-4">
      <h1 class="text-3xl font-bold mb-6">Daftar Sekolah Sepak Bola (SSB)</h1>

      <!-- Form Pencarian -->
      <form method="get" class="mb-6 flex flex-col sm:flex-row items-center gap-3">
        <input type="text" name="q" value="<?= htmlspecialchars($keyword) ?>" placeholder="Cari berdasarkan nama atau lokasi..." class="flex-1 p-2 rounded-lg bg-slate-800 text-slate-100 focus:outline-none focus:ring-2 focus:ring-cyan-500">
        
        <select name="sort" class="p-2 rounded-lg bg-slate-800 text-slate-100 focus:outline-none focus:ring-2 focus:ring-purple-500">
          <option value="name_asc" <?= $sort=='name_asc'?'selected':'' ?>>Urutkan: Nama (A-Z)</option>
          <option value="price_asc" <?= $sort=='price_asc'?'selected':'' ?>>Harga Terendah</option>
          <option value="price_desc" <?= $sort=='price_desc'?'selected':'' ?>>Harga Tertinggi</option>
        </select>

        <button type="submit" class="px-4 py-2 rounded-lg accent text-sm font-semibold text-white hover:opacity-90">Terapkan</button>
      </form>

      <!-- Daftar hasil -->
      <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        <?php if ($result && $result->num_rows > 0): ?>
          <?php while ($ssb = $result->fetch_assoc()): ?>
            <div class="card-glass p-5 rounded-2xl hover:bg-slate-800 transition">
              <h2 class="text-lg font-semibold mb-1"><?= htmlspecialchars($ssb['name']) ?></h2>
              <p class="text-slate-400 text-sm mb-3"><?= htmlspecialchars($ssb['location']) ?></p>
              <p class="text-slate-300 text-sm mb-2">Biaya Pendaftaran: <span class="font-semibold text-white">Rp <?= number_format($ssb['price'], 0, ',', '.') ?></span></p>
              <a href="daftar-ssb.php?id=<?= $ssb['id'] ?>" class="block text-center px-3 py-2 rounded-lg accent text-sm font-semibold mt-3 hover:opacity-90">Daftar Sekarang</a>
            </div>
          <?php endwhile; ?>
        <?php else: ?>
          <p class="text-slate-400 italic">Tidak ada SSB yang ditemukan<?= $keyword ? " untuk kata kunci '<b>" . htmlspecialchars($keyword) . "</b>'" : '' ?>.</p>
        <?php endif; ?>
      </div>
    </div>
  </main>

  <!-- Footer -->
  <footer class="bg-slate-900 border-t border-slate-800 mt-10">
    <div class="max-w-6xl mx-auto px-6 py-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
      <div>
        <h3 class="text-lg font-semibold mb-3 text-white">Tentang Kami</h3>
        <p class="text-slate-400 text-sm leading-relaxed">
          The 90' : Football Academy adalah platform yang membantu generasi muda menyalurkan bakat sepak bola mereka ke berbagai SSB terbaik di Indonesia.
        </p>
      </div>
      <div>
        <h3 class="text-lg font-semibold mb-3 text-white">Kontak</h3>
        <ul class="text-slate-400 text-sm space-y-2">
          <li>Email: <a href="mailto:info@the90academy.com" class="text-cyan-400 hover:underline">info@the90academy.com</a></li>
          <li>Telepon: +62 812 3456 7890</li>
          <li>Alamat: Sumedang, Jawa Barat</li>
        </ul>
      </div>
      <div>
        <h3 class="text-lg font-semibold mb-3 text-white">Tautan Cepat</h3>
        <ul class="text-slate-400 text-sm space-y-2">
          <li><a href="index.php" class="hover:text-cyan-400">Beranda</a></li>
          <li><a href="ssb-list.php" class="hover:text-cyan-400">Daftar SSB</a></li>
          <li><a href="daftar-ssb.php" class="hover:text-cyan-400">Pendaftaran</a></li>
          <li><a href="login.php" class="hover:text-cyan-400">Masuk</a></li>
        </ul>
      </div>
      <div>
        <h3 class="text-lg font-semibold mb-3 text-white">Ikuti Kami</h3>
        <div class="flex gap-4 mt-2">
          <a href="#" class="text-slate-400 hover:text-cyan-400">
            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M22.46 6c-.77.35-1.6.58-2.46.69a4.2 4.2 0 001.84-2.32c-.81.48-1.7.83-2.65 1A4.18 4.18 0 0015.5 4c-2.33 0-4.21 1.93-4.21 4.31 0 .34.04.67.11.98-3.5-.18-6.61-1.9-8.69-4.52-.36.65-.56 1.4-.56 2.21 0 1.52.75 2.86 1.89 3.65-.7-.02-1.36-.22-1.94-.54v.05c0 2.12 1.46 3.89 3.39 4.29-.36.1-.74.15-1.13.15-.28 0-.55-.03-.81-.08.55 1.75 2.15 3.02 4.05 3.06A8.37 8.37 0 012 19.54a11.8 11.8 0 006.29 1.88c7.55 0 11.68-6.4 11.68-11.94v-.55c.8-.6 1.5-1.33 2.06-2.17z"/>
            </svg>
          </a>
        </div>
      </div>
    </div>
    <div class="border-t border-slate-800 py-4 text-center text-slate-500 text-sm">
      © 2025 The 90' : Football Academy — All Rights Reserved
    </div>
  </footer>

  <!-- Script -->
  <script>
    // Toggle menu responsif
    const menuToggle = document.getElementById('menu-toggle');
    const menu = document.getElementById('menu');
    menuToggle.addEventListener('click', () => {
      menu.classList.toggle('hidden');
      menu.classList.toggle('flex');
    });

    // Efek splash loading
    window.addEventListener("load", () => {
      const loader = document.getElementById("dashboard-loading");
      setTimeout(() => {
        loader.style.opacity = "0";
        setTimeout(() => loader.remove(), 600);
      }, 1000);
    });
  </script>

</body>
</html>
