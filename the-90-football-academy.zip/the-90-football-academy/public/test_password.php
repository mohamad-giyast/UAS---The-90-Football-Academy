<?php
// test_password.php
// Debug password_verify step-by-step

include 'config.php'; // pastikan ini path yang benar ke config.php

// Ambil hash dari DB untuk admin
$email = 'admin@the90academy.com';
$stmt = $conn->prepare("SELECT password FROM users WHERE email = ? LIMIT 1");
$stmt->bind_param('s', $email);
$stmt->execute();
$res = $stmt->get_result();
$row = $res ? $res->fetch_assoc() : null;

$hash = $row['password'] ?? '(not found)';

// Simulasi input dari form — ganti ini sesuai yang kamu ketik saat login
$input_password = 'admin123';

// Variasi trimmed/untrimmed
$trimmed = trim($input_password);
$rawhex = bin2hex($input_password);
$trimhex = bin2hex($trimmed);

echo "<pre>";
echo "PHP version: " . phpversion() . PHP_EOL . PHP_EOL;

echo "Email checked: $email" . PHP_EOL;
echo "Hash from DB: " . $hash . PHP_EOL;
echo "Hash length: " . strlen($hash) . PHP_EOL . PHP_EOL;

echo "Input password (raw): [$input_password]" . PHP_EOL;
echo "Input length raw: " . strlen($input_password) . PHP_EOL;
echo "Input hex raw: $rawhex" . PHP_EOL . PHP_EOL;

echo "Input password (trimmed): [$trimmed]" . PHP_EOL;
echo "Trimmed length: " . strlen($trimmed) . PHP_EOL;
echo "Input hex trimmed: $trimhex" . PHP_EOL . PHP_EOL;

echo "password_verify(raw): " . (password_verify($input_password, $hash) ? 'TRUE' : 'FALSE') . PHP_EOL;
echo "password_verify(trimmed): " . (password_verify($trimmed, $hash) ? 'TRUE' : 'FALSE') . PHP_EOL . PHP_EOL;

// Extra checks
echo "strcmp raw vs trimmed: " . (strcmp($input_password, $trimmed) === 0 ? 'SAME' : 'DIFFER') . PHP_EOL;
echo "Does hash look like bcrypt? starts with \$2y\$ or \$2b\$? -> " . (preg_match('/^\\$2[yb]\\$[0-9]{2}\\$.+$/', $hash) ? 'YES' : 'NO') . PHP_EOL;

echo "</pre>";
