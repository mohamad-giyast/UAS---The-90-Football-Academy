<?php
session_start();
include 'config.php';

// Cek login
if (!isset($_SESSION['user_id'])) {
  header("Location: login.php");
  exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];
$user_role = $_SESSION['role'] ?? 'user';
$success = false;
$error = '';

// Ambil data user
$user_query = $conn->query("SELECT * FROM users WHERE id = '$user_id'");
$user = $user_query->fetch_assoc();

// Update profil
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nama_anak = $_POST['nama_anak'];
  $tempat_lahir = $_POST['tempat_lahir'];
  $tanggal_lahir = $_POST['tanggal_lahir'];
  $jenis_kelamin = $_POST['jenis_kelamin'];
  $alamat = $_POST['alamat'];
  $telepon = $_POST['telepon'];

  $update = $conn->prepare("
      UPDATE users 
      SET nama_anak=?, tempat_lahir=?, tanggal_lahir=?, jenis_kelamin=?, alamat=?, telepon=? 
      WHERE id=?
  ");
  $update->bind_param("ssssssi", $nama_anak, $tempat_lahir, $tanggal_lahir, $jenis_kelamin, $alamat, $telepon, $user_id);

  if ($update->execute()) {
    $success = true;
  } else {
    $error = "Gagal memperbarui profil. Silakan coba lagi.";
  }
}

// Ambil ulang data user
$user_query = $conn->query("SELECT * FROM users WHERE id = '$user_id'");
$user = $user_query->fetch_assoc();

// Ambil data pendaftaran user
$reg_query = $conn->query("
  SELECT r.id AS reg_id, r.status, s.name AS ssb_name
  FROM registrations r
  JOIN ssb s ON r.ssb_id = s.id
  WHERE r.user_id = '$user_id'
  ORDER BY r.date_registered DESC
  LIMIT 1
");
$registration = $reg_query->fetch_assoc();
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Profil - The 90' : Football Academy</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
  <link rel="icon" type="image/png" href="Assets/logo-trans.png">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body {
      font-family: 'Inter', sans-serif;
      background: linear-gradient(180deg, #071022 0%, #0b1220 60%, #071022 100%);
      color: #fff;
    }
    .card-glass {
      background: linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02));
      backdrop-filter: blur(8px);
    }
    .accent {
      background: linear-gradient(90deg, #06b6d4, #7c3aed);
    }
    input, select, textarea {
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.1);
      border-radius: 0.5rem;
      padding: 0.5rem;
      color: #fff;
      width: 100%;
    }
    #popup-success, #popup-confirm {
      animation: fadeIn 0.4s ease;
    }
    @keyframes fadeIn {
      from {opacity: 0; transform: scale(0.95);}
      to {opacity: 1; transform: scale(1);}
    }
  </style>
</head>

<body class="min-h-screen flex flex-col relative">

  <!-- Splash Loading -->
  <div id="dashboard-loading" class="fixed inset-0 bg-slate-950 flex flex-col items-center justify-center z-50">
    <img src="Assets/logo-trans.png" alt="Logo" class="w-20 animate-bounce mb-4">
    <div class="border-4 border-cyan-500 border-t-transparent rounded-full w-10 h-10 animate-spin"></div>
    <p class="mt-3 text-slate-300 text-sm tracking-wide">Memuat Profil...</p>
  </div>

  <!-- Navbar -->
  <nav class="px-4 py-4 flex items-center justify-between max-w-6xl mx-auto w-full relative">
    <div class="flex items-center gap-3">
      <div class="w-10 h-10 rounded-2xl overflow-hidden shadow-lg">
        <img src="Assets/logo.png" alt="Logo" class="w-full h-full object-cover">
      </div>
      <div>
        <span class="text-lg font-semibold block">The 90' : Football Academy</span>
        <div class="text-xs text-slate-400">Pendaftaran Sekolah Sepak Bola</div>
      </div>
    </div>

    <button id="menu-toggle" class="md:hidden p-2 rounded-lg card-glass">
      <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none"
           viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round"
              stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
      </svg>
    </button>

    <div id="menu" 
         class="hidden md:flex flex-col md:flex-row absolute md:static top-full right-0 left-0 
                bg-slate-900 md:bg-transparent p-4 md:p-0 mt-2 md:mt-0 
                rounded-xl md:rounded-none shadow-lg md:shadow-none z-50 transition-all duration-300">
      <a href="index.php" class="px-3 py-2 rounded-lg card-glass text-sm text-center mb-2 md:mb-0 md:mx-1 hover:bg-slate-800">Beranda</a>
      <a href="ssb-list.php" class="px-3 py-2 rounded-lg card-glass text-sm text-center mb-2 md:mb-0 md:mx-1 hover:bg-slate-800">Cari SSB</a>
      <a href="daftar-ssb.php" class="px-3 py-2 rounded-lg card-glass text-sm text-center mb-2 md:mb-0 md:mx-1 hover:bg-slate-800">Daftar SSB</a>
      <a href="profile.php" class="px-3 py-2 rounded-lg accent text-sm text-center mb-2 md:mb-0 md:mx-1">Profil</a>
      <?php if ($user_role === 'admin'): ?>
        <a href="admin/admin-dashboard.php" class="px-3 py-2 rounded-lg bg-purple-800 text-sm text-center mb-2 md:mb-0 md:mx-1 hover:bg-purple-700">Admin Panel</a>
      <?php endif; ?>
      <a href="logout.php" class="px-3 py-2 rounded-lg accent text-sm text-center shadow md:mx-1 hover:opacity-90">Keluar</a>
    </div>
  </nav>

  <!-- Konten -->
  <main class="flex-1 w-full max-w-5xl mx-auto px-4 pb-10 mt-6">
    <div class="card-glass rounded-2xl p-6 sm:p-8 mt-4">
      <h1 class="text-3xl font-bold mb-6">Profil Pengguna</h1>

      <form method="POST" class="space-y-4">
        <div class="grid sm:grid-cols-2 gap-4">
          <div>
            <label class="text-sm text-slate-300">Nama</label>
            <input type="text" value="<?= htmlspecialchars($user['name']) ?>" disabled>
          </div>
          <div>
            <label class="text-sm text-slate-300">Email</label>
            <input type="email" value="<?= htmlspecialchars($user['email']) ?>" disabled>
          </div>
          <div>
            <label class="text-sm text-slate-300">Nama Anak</label>
            <input type="text" name="nama_anak" value="<?= htmlspecialchars($user['nama_anak'] ?? '') ?>" required>
          </div>
          <div>
            <label class="text-sm text-slate-300">Tempat Lahir</label>
            <input type="text" name="tempat_lahir" value="<?= htmlspecialchars($user['tempat_lahir'] ?? '') ?>">
          </div>
          <div>
            <label class="text-sm text-slate-300">Tanggal Lahir</label>
            <input type="date" name="tanggal_lahir" value="<?= htmlspecialchars($user['tanggal_lahir'] ?? '') ?>">
          </div>
          <div>
            <label class="text-sm text-slate-300">Jenis Kelamin</label>
            <select name="jenis_kelamin">
              <option value="">-- Pilih --</option>
              <option value="Laki-laki" <?= ($user['jenis_kelamin'] ?? '') === 'Laki-laki' ? 'selected' : '' ?>>Laki-laki</option>
              <option value="Perempuan" <?= ($user['jenis_kelamin'] ?? '') === 'Perempuan' ? 'selected' : '' ?>>Perempuan</option>
            </select>
          </div>
          <div class="sm:col-span-2">
            <label class="text-sm text-slate-300">Alamat</label>
            <textarea name="alamat" rows="2"><?= htmlspecialchars($user['alamat'] ?? '') ?></textarea>
          </div>
          <div class="sm:col-span-2">
            <label class="text-sm text-slate-300">No. Telepon</label>
            <input type="text" name="telepon" value="<?= htmlspecialchars($user['telepon'] ?? '') ?>">
          </div>
        </div>

        <div class="flex gap-3 pt-4">
          <button type="submit" class="px-5 py-2 rounded-lg accent text-white font-semibold hover:opacity-90">Simpan Perubahan</button>
          <a href="logout.php" class="px-5 py-2 rounded-lg bg-red-600 text-white font-semibold hover:bg-red-700">Keluar</a>
        </div>
      </form>

      <hr class="my-6 border-slate-700">

      <!-- Status Pendaftaran -->
      <?php if ($registration): ?>
        <h2 class="text-xl font-semibold mb-2">Status Pendaftaran</h2>
        <p><strong>SSB:</strong> <?= htmlspecialchars($registration['ssb_name']) ?></p>
        <p><strong>Status:</strong>
          <?php if ($registration['status'] === 'Menunggu'): ?>
            <span class="text-yellow-400 font-semibold">Menunggu Konfirmasi</span>
          <?php elseif ($registration['status'] === 'Dikonfirmasi'): ?>
            <span class="text-green-400 font-semibold">Terdaftar</span>
          <?php elseif ($registration['status'] === 'Dibatalkan'): ?>
            <span class="text-red-400 font-semibold">Dibatalkan</span>
          <?php endif; ?>
        </p>

        <div class="mt-4">
          <?php if (in_array($registration['status'], ['Menunggu', 'Dikonfirmasi'])): ?>
            <button onclick="showConfirmPopup(<?= $registration['reg_id'] ?>, '<?= $registration['status'] ?>')" 
                    class="px-4 py-2 bg-red-600 hover:bg-red-700 rounded-lg text-white text-sm font-semibold">
              <?= $registration['status'] === 'Menunggu' ? 'Batalkan Pendaftaran' : 'Keluar dari SSB' ?>
            </button>
          <?php endif; ?>
        </div>
      <?php else: ?>
        <p class="text-slate-400">Anda belum terdaftar di SSB mana pun.</p>
      <?php endif; ?>
    </div>
  </main>

  <footer class="py-6 text-center text-slate-400 text-sm border-t border-slate-800">
    © 2025 The 90' : Football Academy
  </footer>

  <!-- ✅ Popup Success -->
  <?php if ($success): ?>
  <div id="popup-success" class="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
    <div class="bg-green-600 rounded-xl p-6 shadow-lg text-center max-w-sm">
      <h2 class="text-xl font-bold mb-2">Berhasil!</h2>
      <p>Profil kamu telah diperbarui.</p>
      <button onclick="document.getElementById('popup-success').remove()" 
              class="mt-4 px-4 py-2 bg-white text-green-700 rounded-lg font-semibold">
        Tutup
      </button>
    </div>
  </div>
  <?php endif; ?>

  <!-- ✅ Popup Konfirmasi -->
  <div id="popup-confirm" class="hidden fixed inset-0 bg-black/60 flex items-center justify-center z-50">
    <div class="bg-slate-800 rounded-xl p-6 shadow-lg text-center max-w-sm border border-slate-700">
      <h2 class="text-xl font-bold mb-3">Konfirmasi</h2>
      <p id="confirm-text" class="text-slate-300 mb-4">Yakin ingin membatalkan pendaftaran ini?</p>
      <div class="flex justify-center gap-3">
        <button id="confirm-yes" class="px-4 py-2 bg-red-600 hover:bg-red-700 rounded-lg">Ya</button>
        <button onclick="closeConfirmPopup()" class="px-4 py-2 bg-slate-600 hover:bg-slate-700 rounded-lg">Tidak</button>
      </div>
    </div>
  </div>

  <script>
    // Toggle menu responsif
    const menuToggle = document.getElementById('menu-toggle');
    const menu = document.getElementById('menu');
    menuToggle.addEventListener('click', () => {
      menu.classList.toggle('hidden');
      menu.classList.toggle('flex');
    });

    // Efek loading splash
    window.addEventListener("load", () => {
      const loader = document.getElementById("dashboard-loading");
      setTimeout(() => {
        loader.style.opacity = "0";
        setTimeout(() => loader.remove(), 600);
      }, 1000);
    });

    // Popup Konfirmasi Batalkan / Keluar
    function showConfirmPopup(id, status) {
      document.getElementById('popup-confirm').classList.remove('hidden');
      const text = status === 'Menunggu'
        ? 'Yakin ingin membatalkan pendaftaran ini?'
        : 'Yakin ingin keluar dari SSB ini?';
      document.getElementById('confirm-text').textContent = text;

      document.getElementById('confirm-yes').onclick = () => {
        window.location.href = `leave_ssb.php?registration_id=${id}`;
      };
    }
    function closeConfirmPopup() {
      document.getElementById('popup-confirm').classList.add('hidden');
    }
  </script>
</body>
</html>
