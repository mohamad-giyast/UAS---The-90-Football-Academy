-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 12, 2025 at 04:54 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `the90academy`
--

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `registration_id` int(11) NOT NULL,
  `amount` decimal(10,2) DEFAULT 0.00,
  `method` varchar(50) DEFAULT 'transfer',
  `status` varchar(50) DEFAULT 'pending',
  `date_paid` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `registrations`
--

CREATE TABLE `registrations` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ssb_id` int(11) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_detail` text DEFAULT NULL,
  `date_registered` datetime DEFAULT current_timestamp(),
  `status` varchar(50) DEFAULT 'Menunggu'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registrations`
--

INSERT INTO `registrations` (`id`, `user_id`, `ssb_id`, `payment_method`, `payment_detail`, `date_registered`, `status`) VALUES
(4, 4, 4, 'Dana', NULL, '2025-10-14 02:32:31', 'Dibatalkan'),
(9, 14, 7, 'Transfer Bank', NULL, '2025-10-14 10:40:10', 'Dikonfirmasi'),
(10, 15, 7, 'Transfer Bank', NULL, '2025-10-17 13:02:54', 'Dikonfirmasi'),
(11, 16, 2, 'DANA', NULL, '2025-10-17 14:45:22', 'Dikonfirmasi');

-- --------------------------------------------------------

--
-- Table structure for table `registration_details`
--

CREATE TABLE `registration_details` (
  `id` int(11) NOT NULL,
  `registration_id` int(11) NOT NULL,
  `child_name` varchar(150) DEFAULT NULL,
  `child_age` int(11) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `parent_phone` varchar(50) DEFAULT NULL,
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ssb`
--

CREATE TABLE `ssb` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `location` varchar(100) NOT NULL,
  `city` varchar(50) DEFAULT NULL,
  `level` varchar(50) DEFAULT NULL,
  `coach` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ssb`
--

INSERT INTO `ssb` (`id`, `name`, `location`, `city`, `level`, `coach`, `price`, `description`) VALUES
(1, 'SSB Muda Jaya', 'Jakarta', 'Jakarta', 'Pemula', 'Coach Bima', 750000.00, NULL),
(2, 'Golden Boots', 'Depok', 'Depok', 'Lanjutan', 'Coach Riko', 750000.00, NULL),
(4, 'SSB BPP', 'Sumedang', 'Sumedang', 'Pemula', 'Cecep Zamzam', 500000.00, NULL),
(7, 'Real Madrid Academy', 'Sumedang', 'Madrid', 'Lanjutan', '0', 10000000.00, NULL),
(8, 'Unsap Academy', '', 'Sumedang', 'Pemula', 'Shin Tae Yong', 550000.00, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('user','admin') DEFAULT 'user',
  `nama_anak` varchar(100) DEFAULT NULL,
  `tempat_lahir` varchar(100) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `telepon` varchar(20) DEFAULT NULL,
  `jenis_kelamin` enum('Laki-laki','Perempuan') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `nama_anak`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `telepon`, `jenis_kelamin`) VALUES
(4, 'Mohamad Giyast Al Barro Ruhiyat', 'giyastalbarro06@gmail.com', '$2y$10$.xzCvrwkhM/9FEMXN08nVOpwyMz.afMji.yqrJv8S2YEC8BwT77a.', 'user', 'Jay Idzes', 'Tanjungsari', '2007-11-24', 'Tanjungsari', '087825549324', 'Laki-laki'),
(13, 'Administrator', 'admin@the90academy.com', 'admin123', 'admin', NULL, NULL, NULL, NULL, NULL, NULL),
(14, 'Cristiano Ronaldo', 'cristiano@gmail.com', '$2y$10$Gz3t2ABpS28bqeprBoXEHuhJnZ/.gBEo2ZYwTkZzAGxk4BQkTlAN.', 'user', 'Cristiano Junior', 'Spain', '2008-03-04', 'Portugal', '', 'Laki-laki'),
(15, 'Kylian Mbappe', 'mbappe@gmail.com', '$2y$10$0lpj18Pjvx6X0QPNI/XyU.1W6vS8dBWhAwZjSKxlUCGbj4R9.QqF6', 'user', NULL, NULL, NULL, NULL, NULL, NULL),
(16, 'Patrick Kluivert', 'patrick@gmail.com', '$2y$10$yaoL3QocsEyqpT6aVEZifOpvX0T0LMPlu4TBualvvICZnUcC4bGJO', 'user', 'Justin Kluivert', 'Amsterdam, Netherland ', '2004-06-22', 'Amsterdam, 45563', '+773453432 673', 'Laki-laki'),
(17, 'Jajang Hasan', 'jajanghasan123@gmail.com', '$2y$10$vNH2jvIBis2HFRyS6.mHO.0qs1Xfy5c3NqUz4Sq10GDpuIz7TGBlu', 'user', 'Hasan Jr', 'Majalengka', '2012-06-12', 'Majalengka', '083584635233', 'Laki-laki');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `registration_id` (`registration_id`);

--
-- Indexes for table `registrations`
--
ALTER TABLE `registrations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `ssb_id` (`ssb_id`);

--
-- Indexes for table `registration_details`
--
ALTER TABLE `registration_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `registration_id` (`registration_id`);

--
-- Indexes for table `ssb`
--
ALTER TABLE `ssb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `registrations`
--
ALTER TABLE `registrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `registration_details`
--
ALTER TABLE `registration_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ssb`
--
ALTER TABLE `ssb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`registration_id`) REFERENCES `registrations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `registrations`
--
ALTER TABLE `registrations`
  ADD CONSTRAINT `registrations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `registrations_ibfk_2` FOREIGN KEY (`ssb_id`) REFERENCES `ssb` (`id`);

--
-- Constraints for table `registration_details`
--
ALTER TABLE `registration_details`
  ADD CONSTRAINT `registration_details_ibfk_1` FOREIGN KEY (`registration_id`) REFERENCES `registrations` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
