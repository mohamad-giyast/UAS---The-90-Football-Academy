<?php
include 'config.php';
$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm'];

    if ($password !== $confirm) {
        $error = "Password dan konfirmasi tidak sama!";
    } else {
        // Cek apakah email sudah terdaftar
        $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $error = "Email sudah terdaftar, silakan login.";
        } else {
            // Simpan akun baru
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'user')");
            $stmt->bind_param("sss", $name, $email, $hashed);
            if ($stmt->execute()) {
                $success = true;
            } else {
                $error = "Gagal menyimpan data.";
            }
        }
    }
}
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Daftar Akun — The 90' : Football Academy</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
  <link rel="icon" type="image/png" href="Assets/logo-trans.png">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    html,body{height:100%;font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,'Helvetica Neue',Arial}
    .app-bg{background:linear-gradient(180deg,#071022 0%, #0b1220 60%, #071022 100%);}
    .card-glass{background:linear-gradient(180deg,rgba(255,255,255,0.05),rgba(255,255,255,0.02));backdrop-filter:blur(8px);}
    .accent{background:linear-gradient(90deg,#06b6d4,#7c3aed);}
  </style>
</head>
<body class="app-bg text-slate-100 antialiased">
  <div class="min-h-screen flex items-center justify-center px-4">
    <div class="w-full max-w-md card-glass rounded-2xl p-6">
      <h1 class="text-center text-2xl font-bold mb-4">Buat Akun Baru</h1>

      <?php if ($success): ?>
        <div class="mb-4 p-3 bg-green-700 rounded text-white">
          ✅ Akun berhasil dibuat! <a href="login.php" class="underline text-cyan-300">Login di sini</a>.
        </div>
      <?php elseif ($error): ?>
        <div class="mb-4 p-3 bg-red-700 rounded text-white"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <form method="POST" class="space-y-4">
        <div>
          <label class="text-sm text-slate-300 block mb-1">Nama Lengkap</label>
          <input name="name" type="text" required class="w-full px-3 py-2 rounded bg-slate-900 text-sm">
        </div>
        <div>
          <label class="text-sm text-slate-300 block mb-1">Email</label>
          <input name="email" type="email" required class="w-full px-3 py-2 rounded bg-slate-900 text-sm">
        </div>
        <div>
          <label class="text-sm text-slate-300 block mb-1">Password</label>
          <input name="password" type="password" required minlength="6" class="w-full px-3 py-2 rounded bg-slate-900 text-sm">
        </div>
        <div>
          <label class="text-sm text-slate-300 block mb-1">Konfirmasi Password</label>
          <input name="confirm" type="password" required class="w-full px-3 py-2 rounded bg-slate-900 text-sm">
        </div>
        <button type="submit" class="w-full py-2 rounded-lg accent text-white font-semibold hover:opacity-90">Daftar</button>
      </form>

      <p class="text-center text-sm text-slate-400 mt-4">
        Sudah punya akun? <a href="login.php" class="text-cyan-300">Masuk di sini</a>.
      </p>
    </div>
  </div>
</body>
</html>
