import Http from './Http'
const Fortify = {
    Http: Object.assign(Http, Http),
}

export default Fortify