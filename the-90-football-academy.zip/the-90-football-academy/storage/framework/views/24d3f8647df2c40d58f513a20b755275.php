## Inertia + React

- Use ___SINGLE_BACKTICK___router.visit()___SINGLE_BACKTICK___ or ___SINGLE_BACKTICK___<Link>___SINGLE_BACKTICK___ for navigation instead of traditional links.

___BOOST_SNIPPET_0___
<?php /**PATH C:\Windows\System32\the-90-football-academy\storage\framework\views/27241cd172cb80748bbcee6b68ab5434.blade.php ENDPATH**/ ?>