<?php
/** @var \Laravel\Boost\Install\GuidelineAssist $assist */
?>
## Inertia v2 + React Forms

<?php if($assist->inertia()->hasFormComponent()): ?>
___BOOST_SNIPPET_0___
<?php endif; ?>

<?php if($assist->inertia()->hasFormComponent() === false): ?>

___BOOST_SNIPPET_1___
<?php endif; ?>
<?php /**PATH C:\Windows\System32\the-90-football-academy\storage\framework\views/4e05d1774f177de5a96e119d1d25ccff.blade.php ENDPATH**/ ?>